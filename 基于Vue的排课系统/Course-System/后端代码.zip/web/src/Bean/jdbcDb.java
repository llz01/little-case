package Bean;
import java.sql.*;
public class jdbcDb {

		Connection conn = null;		
		Statement stmt = null;		
		ResultSet rs = null;		
		String sqlStr;		
		    public jdbcDb()  throws SQLException {
			dbOperation conMg = new dbOperation();
			try{
			conn =  conMg.getConnecton();
			stmt = conn.createStatement();
			}
			catch(SQLException e)
			{
				throw e;
			}
		}
		public ResultSet select(String sql)
		{
			ResultSet rs = null;
			try {
				rs = stmt.executeQuery(sql);
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			return rs;
		}
		public void Update(String sql)
		{
			try {
				stmt.executeUpdate(sql);
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		}
		
	}
