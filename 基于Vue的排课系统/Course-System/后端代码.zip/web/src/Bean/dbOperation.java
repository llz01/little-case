package Bean;
import java.sql.*;
public class dbOperation {
		String driverName;
		String url;
		String user;
		String password;
		public dbOperation() {
		driverName = "com.mysql.jdbc.Driver"; 
	    url = "jdbc:mysql://localhost:3306/jsp";  
	    user = "root";
	    password = "1234";
		}	
		public Connection getConnecton()
		{
			try {
	            Class.forName(driverName);
	            return DriverManager.getConnection(url, user, password);
	        }
	        catch (Exception e) {
	            e.printStackTrace();
	            return null;
	        }
		}
		public String getDriverName() {
			return driverName;
		}
		public void setDriverName(String driverName) {
			this.driverName = driverName;
		}
		public String getUrl() {
			return url;
		}
		public void setUrl(String url) {
			this.url = url;
		}
		public String getUser() {
			return user;
		}
		public void setUser(String user) {
			this.user = user;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
	}