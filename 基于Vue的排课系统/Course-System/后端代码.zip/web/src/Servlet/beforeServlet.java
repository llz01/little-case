package Servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.jdbcDb;
import net.sf.json.JSONObject;

public class beforeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public beforeServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		  String json=null;
	   if(request.getParameter("data")!=null)
	    	json=request.getParameter("data");   
	     if(json!=null) {
	    	 JSONObject jSon=JSONObject.fromObject(json.toString());
	   	   int k=Integer.parseInt(jSon.getString("state"));
	   	   StringBuffer p=new StringBuffer();
	   	   if(k==1) {
	   		 String appNo=null;
	   		 String courseNo=null;
	   		 String courseIdx=null;
	   		 String classNo=null;
	   		 String teacherNo=null;
	   		 String appTeam=null;
	   		 String appStuNum=null;
	   		 String arrangeWeek=null;
	   		 String arrangeInterval=null;
	   		 String arrangeDay=null;
	   		 String  roomNo=null;
	   		 String StuNum=null;
	   		 String expItemNo=null;
	   		JSONObject JSON=JSONObject.fromObject(jSon.getString("message"));
	   		appNo=JSON.getString("appNo");
	   		courseNo=JSON.getString("courseNo");
	   		courseIdx=JSON.getString("courseIdx");
	   		teacherNo=JSON.getString("teacherNo");
	   	   appTeam=JSON.getString("appTeam");
	   	arrangeWeek=JSON.getString("arrangeWeek");
	   	arrangeInterval=JSON.getString("arrangeInterval");
	   	arrangeDay=JSON.getString("arrangeDay");
	   	roomNo=JSON.getString("roomNo");
	   	StuNum=JSON.getString("stuNum");
	   	expItemNo=JSON.getString("expItemNo");
	   	appStuNum=JSON.getString("appStuNum");
	   	classNo=JSON.getString("classNo");
	   	try {
			jdbcDb db=new jdbcDb();
			String  sql=null;
			sql="Insert into app_info(APP_NO,COURSE_IDX,APP_STU_NUM,APP_TERM,FK_COURSE_NO,FK_CLASS_NO,FK_TEACHER_NO) ";
	        sql+="values('"+appNo+"','"+courseIdx+"','"+appStuNum+"','"+appTeam+"','"+courseNo+"','"+classNo+"','"+teacherNo+"')";
	        db.Update(sql);
	        String Sql=null;
	        Sql="Insert into arrange_info(STU_NUM,ARRANGE_WEEK,ARRANGE_DAY,ARRANGE_INTERVAL,FK_APP_NO,FK_EXP_ITEM_NO,FK_ROOM_NO) ";
	       Sql+="values('"+StuNum+"','"+arrangeWeek+"','"+	arrangeDay+"','"+	arrangeInterval+"','"+appNo+"','"+	expItemNo+"','"+roomNo+"')";
	   	   db.Update(Sql);
	   	} catch (SQLException e) {
		
			e.printStackTrace();
		}
	   	
	   		
	   	   }
	    	 
	     }
	}

}
