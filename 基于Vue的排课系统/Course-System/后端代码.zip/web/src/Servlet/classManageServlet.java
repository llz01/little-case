package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.jdbcDb;
import net.sf.json.JSONObject;

public class classManageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public classManageServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  request.setCharacterEncoding("utf-8");
		  String json=null;
 	   if(request.getParameter("data")!=null)
	    	json=request.getParameter("data");   
 	   if(json!=null) {
 	   JSONObject jSon=JSONObject.fromObject(json.toString());
 	   int k=Integer.parseInt(jSon.getString("state"));
 	   StringBuffer p=new StringBuffer();
 	    if(k==1) {
 	      String classNo=null;
 	      classNo=jSon.getString("message");
 	      try {
			jdbcDb db=new jdbcDb();
			String sql=null;
			sql="delete from class_info where CLASS_NO='"+classNo+"'";
			db.Update(sql);
			p.append("{").append("\"state\":").append("\"SUC\"").append("}");
		} catch (SQLException e) {
			p.append("{").append("\"state\":").append("\"ERR\"").append("}");
		}
 	    }
 	    else if(k==2) {
 	    	String classNo=null;
 	    	String majorName=null;
 	    	String className=null;
 	    	String classGrade=null;
    JSONObject JSON=JSONObject.fromObject(jSon.getString("message"));
             classNo=JSON.getString("classNo");
              majorName=JSON.getString("majorName");
              className=JSON.getString("className");
              classGrade=JSON.getString("classGrade");
            try {
				jdbcDb db=new jdbcDb();
		String Sql="update class_info set CLASS_NO='"+classNo+"',MAJOR_NAME='"+majorName+"',CLASS_NAME='"+className+"',CLASS_GRADE='"+classGrade+"' where CLASS_NO='"+classNo+"'";
		db.Update(Sql);
		p.append("{").append("\"state\":").append("\"SUC\"").append("}");
			} catch (SQLException e) {
			
				p.append("{").append("\"state\":").append("\"ERR\"").append("}");
			}
 	    }
 	    else if(k==3) {
 	     	String classNo=null;
	    	String majorName=null;
	    	String className=null;
	    	String classGrade=null;
 JSONObject JSON=JSONObject.fromObject(jSon.getString("message"));
          classNo=JSON.getString("classNo");
          majorName=JSON.getString("majorName");
          className=JSON.getString("className");
          classGrade=JSON.getString("classGrade");	
          try {
				jdbcDb db=new jdbcDb();
		String Sql="Insert into class_info(CLASS_NO,MAJOR_NAME,CLASS_NAME,CLASS_GRADE) values('"+classNo+"','"+majorName+"','"+className+"','"+classGrade+"')";	
		db.Update(Sql);
		p.append("{").append("\"state\":").append("\"SUC\"").append("}");
			} catch (SQLException e) {
			
				p.append("{").append("\"state\":").append("\"ERR\"").append("}");
			}
 	    }
 	JSONObject Json=JSONObject.fromObject(p.toString());
 	PrintWriter out=response.getWriter();
	String JSon=Json.toString();
    JSon=URLEncoder.encode(JSon,"utf-8");
 	out.println(JSon);
	}     
	}

}
