package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.jdbcDb;
import net.sf.json.JSONObject;

public class courseServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public courseServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StringBuffer json=new StringBuffer();
		try {
				jdbcDb db=new jdbcDb();
				String sql=null;
				sql="select * from course_info";
				ResultSet rs=null;
				rs=db.select(sql);
				if(rs.next()) {
					json.append("{").append("\"state\":").append("\"SUC\"").append(",");
					json.append("\"message\":").append("[");
                     rs.previous();
					while(rs.next()) {
						if(rs.getRow()!=1)
							json.append(",");
				json.append("{").append("\"courseNo\":").append("\"").append(rs.getString(1)).append("\"");
				json.append(",").append("\"courseName\":").append("\"").append(rs.getString(2)).append("\"");
				json.append(",").append("\"courseHour\":").append("\"").append(rs.getString(3)).append("\"");
				json.append(",").append("\"courseExpHour\":").append("\"").append(rs.getString(4)).append("\"");
				json.append(",").append("\"courseCredit\":").append("\"").append(rs.getString(5)).append("\"}");
					
					}
					json.append("]").append("}");
				}
				else {
					json.append("{").append("\"state\":").append("\"ER\"").append("}");
				}	
			} catch (SQLException e) {
				json.append("{").append("\"state\":").append("\"ERR\"").append("}");
			}
		      JSONObject jSon=JSONObject.fromObject(json.toString());
				String Json=jSon.toString();
              Json=URLEncoder.encode(Json,"utf-8");
              PrintWriter out=response.getWriter();
              out.println(Json);
	}

}
