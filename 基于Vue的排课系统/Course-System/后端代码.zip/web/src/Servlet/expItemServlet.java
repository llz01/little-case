package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.jdbcDb;
import net.sf.json.JSONObject;


public class expItemServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public expItemServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		     StringBuffer p=new StringBuffer();
		try {
 			jdbcDb db=new jdbcDb();
 	       String Sql="select * from exp_item";
 	       ResultSet rs=null;
 	       rs=db.select(Sql);
 	       if(rs.next()) {
 	p.append("{").append("\"state\":").append("\"SUC\"").append(",");
 	p.append("\"message\":").append("[");
 	    rs.previous();
 	    while(rs.next()) {
 	    	if(rs.getRow()!=1)
 	    		p.append(",");
  p.append("{").append("\"expItemNo\":").append("\"").append(rs.getString(1)).append("\"");
  p.append(",").append("\"expItemHour\":").append("\"").append(rs.getString(2)).append("\"");
  p.append(",").append("\"expType\":").append("\"").append(rs.getString(3)).append("\"");	    
  p.append(",").append("\"expItemName\":").append("\"").append(rs.getString(4)).append("\"");	    
  p.append(",").append("\"courseNo\":").append("\"").append(rs.getString(5)).append("\"}");	    
 	    }
 	  p.append("]").append("}");
 	  }
 	  else {
 		 p.append("{").append("\"state\":").append("\"ER\"").append(",");
 	  }
 	
 		} catch (SQLException e) {
 		
 			p.append("{").append("\"state\":").append("\"ERR\"").append("}");
 		}
 	JSONObject Json=JSONObject.fromObject(p.toString());
 	PrintWriter out=response.getWriter();
	String JSon=Json.toString();
    JSon=URLEncoder.encode(JSon,"utf-8");
 	out.println(JSon);
	}
}
