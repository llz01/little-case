package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.jdbcDb;
import net.sf.json.JSONObject;

public class courseManageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public courseManageServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  request.setCharacterEncoding("utf-8");
		  String json=null;
 	   if(request.getParameter("data")!=null)
	    	json=request.getParameter("data");   
 	   System.out.println(json);
 	   if(json!=null) {
 	   JSONObject jSon=JSONObject.fromObject(json.toString());
 	   int k=Integer.parseInt(jSon.getString("state"));
 	   StringBuffer p=new StringBuffer();
 	    if(k==1) {
 	      String courseNo=null;
 	      courseNo=jSon.getString("message");
 	      try {
			jdbcDb db=new jdbcDb();
			String sql=null;
			sql="delete from course_info where course_NO='"+courseNo+"'";
			db.Update(sql);
			p.append("{").append("\"state\":").append("\"SUC\"").append("}");
		} catch (SQLException e) {
			p.append("{").append("\"state\":").append("\"ERR\"").append("}");
		}
 	    }
 	    else if(k==2) {
 	    	String courseNo=null;
 	    	String courseName=null;
 	    	String courseHour=null;
 	    	String courseExpHour=null;
 	    	String courseCredit=null;
     JSONObject JSON=JSONObject.fromObject(jSon.getString("message"));
     courseNo=JSON.getString("courseNo");
     courseName=JSON.getString("courseName");
     courseHour=JSON.getString("courseHour");
     courseExpHour=JSON.getString("courseExpHour");
     courseCredit=JSON.getString("courseCredit");
            try {
				jdbcDb db=new jdbcDb();
		String Sql="update course_info set COURSE_NAME='"+courseName+"', COURSE_HOUR='"+courseHour+"',COURSE_EXP_HOUR='"+courseExpHour+"',COURSE_CREDIT='"+ courseCredit+"' where COURSE_NO='"+courseNo+"'";
		db.Update(Sql);
		p.append("{").append("\"state\":").append("\"SUC\"").append("}");
			} catch (SQLException e) {
			
				p.append("{").append("\"state\":").append("\"ERR\"").append("}");
			}
 	    }
 	    else if(k==3) {
 	    	String courseNo=null;
 	    	String courseName=null;
 	    	String courseHour=null;
 	    	String courseExpHour=null;
 	    	String courseCredit=null;
     JSONObject JSON=JSONObject.fromObject(jSon.getString("message"));
     courseNo=JSON.getString("courseNo");
     courseName=JSON.getString("courseName");
     courseHour=JSON.getString("courseHour");
     courseExpHour=JSON.getString("courseExpHour");
     courseCredit=JSON.getString("courseCredit");
     try {
			jdbcDb db=new jdbcDb();
	String Sql="Insert into course_info(COURSE_NO,COURSE_NAME,COURSE_HOUR,COURSE_EXP_HOUR,COURSE_CREDIT) values('"+courseNo+"','"+courseName+"','"+courseHour+"','"+courseExpHour+"','"+courseCredit+"')";
	db.Update(Sql);
	p.append("{").append("\"state\":").append("\"SUC\"").append("}");
		} catch (SQLException e) {
		
			p.append("{").append("\"state\":").append("\"ERR\"").append("}");
		}
 	    }
 	    else if(k==4) {
 	    	String courseNo=null;
 	       JSONObject JSON=JSONObject.fromObject(jSon.getString("message"));
 	      courseNo=JSON.getString("courseNo");
 	     try {
 			jdbcDb db=new jdbcDb();
 	       String Sql="select * from exp_item where FK_COURSE_NO='"+courseNo+"'";
 	       ResultSet rs=null;
 	       rs=db.select(Sql);
 	       if(rs.next()) {
 	p.append("{").append("\"state\":").append("\"SUC\"").append(",");
 	p.append("\"message\":").append("[");
 	    rs.previous();
 	    while(rs.next()) {
 	    	if(rs.getRow()!=1)
 	    		p.append(",");
  p.append("{").append("\"expItemNo\":").append("\"").append(rs.getString(1)).append("\"");
  p.append(",").append("\"expItemHour\":").append("\"").append(rs.getString(2)).append("\"");
  p.append(",").append("\"expType\":").append("\"").append(rs.getString(3)).append("\"");	    
  p.append(",").append("\"expItemName\":").append("\"").append(rs.getString(4)).append("\"");	    
  p.append(",").append("\"courseNo\":").append("\"").append(rs.getString(5)).append("\"}");	    
 	    }
 	  p.append("]").append("}");
 	  }
 	  else {
 		 p.append("{").append("\"state\":").append("\"ER\"").append(",");
 	  }
 	
 		} catch (SQLException e) {
 		
 			p.append("{").append("\"state\":").append("\"ERR\"").append("}");
 		}
 	    }
 	JSONObject JSon=JSONObject.fromObject(p.toString());
 	PrintWriter out=response.getWriter();
	String Json=JSon.toString();
    Json=URLEncoder.encode(Json,"utf-8");
 	out.println(Json);
	}   
	}

}
