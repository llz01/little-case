package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Bean.*;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Login() {
        super();
    
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	     String user = null;
	     String pwd  = null;
	     String data = null;
	     request.setCharacterEncoding("utf-8");
	     if(request.getParameter("data")!=null) {
	    	 data=request.getParameter("data");
	     }
	    if(data!=null) {
          	   JSONObject jSon=JSONObject.fromObject(data.toString());
          	    user=jSon.getString("user");
          	    pwd=jSon.getString("password");
          	    String Json=jSon.toString();
             //Json=URLEncoder.encode(Json,"utf-8");;
	            if(user!=null&&pwd!=null) {
	    	 String sql=null;
	    	 sql="select * from user_admin where (ad_user_name='"+user+"'and ad_user_pwd='"+pwd+"')";
	    	 String Sql=null;
	    	 Sql="select * from teacher_info where (teacher_no='"+user+"'and teacher_pwd='"+pwd+"')";
	         try {
				jdbcDb db=new jdbcDb();
				jdbcDb DB =new jdbcDb();
				ResultSet rs=db.select(sql);
				PrintWriter out=response.getWriter();
				StringBuffer json=new StringBuffer();
				if(rs.next())
				{
					HttpSession session = request.getSession();
				    session.setAttribute("user",""+user+"");
			     json.append("{").append("\"state\":").append("\"SUC\"");
			     json.append(",").append("\"message\":").append("\"1\"").append("}");
				}
				else { 
					ResultSet Rs=null;
					Rs=DB.select(Sql);
					if(Rs.next())
				{
					 json.append("{").append("\"state\":").append("\"SUC\"");
				     json.append(",").append("\"message\":").append("\"2\"").append("}");
				}
			else {
					json.append("{").append("\"state\":").append("\"ERR\"");
					  json.append(",").append("\"message\":").append("\"0\"").append("}");
			}
				}
			JSONObject  JSON = JSONObject.fromObject(json.toString());
			out.println(JSON);
			} catch (SQLException e) {
			
				e.printStackTrace();
			}
	         }
	    }
	}
}
