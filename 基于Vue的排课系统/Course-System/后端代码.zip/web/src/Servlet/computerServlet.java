package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.sun.org.glassfish.external.statistics.annotations.Reset;
import Bean.jdbcDb;
import net.sf.json.JSONObject;
public class computerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
        public computerServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		      String json=null;
		      if(request.getParameter("data")!=null)
		    	  json=request.getParameter("data");
		      if(json!=null) {
		    	 JSONObject JSon=JSONObject.fromObject(json);
		    	   String state=null;
		    	   state=JSon.getString("state");
		    	   int k=Integer.parseInt(state);
		    	   StringBuffer q=new StringBuffer();
		    	   if(k==1) {
		    		  try {
						jdbcDb db=new jdbcDb();
						String sql=null;
						sql="select * from room_info";
						ResultSet rs=null;
						rs=db.select(sql);
						if(rs.next()) {
						     q.append("{").append("\"state\":").append("\"SUC\"").append(",");
						     q.append("\"message\":").append("[");
						     rs.previous();
							while(rs.next()) {
								if(rs.getRow()!=1)
									q.append(",");
						q.append("{").append("\"roomNo\":").append("\"").append(rs.getString(1)).append("\"");
						q.append(",").append("\"roomName\":").append("\"").append(rs.getString(2)).append("\"");
						q.append(",").append("\"deviceNum\":").append("\"").append(rs.getString(3)).append("\"");
						q.append(",").append("\"deviceCapacity\":").append("\"").append(rs.getString(4)).append("\"");
						q.append(",").append("\"deviceDescribe\":").append("\"").append(rs.getString(5)).append("\"");
						q.append("}");
							}
						q.append("]").append("}");
						}
						else {
							 q.append("{").append("\"state\":").append("\"ER\"").append("}");
						}
						
					} catch (SQLException e) {
						 q.append("{").append("\"state\":").append("\"ERR\"").append("}");
		    	   }
		    	 }
		    	   else if(k==2) {
		    		   //JSONObject JSON=JSon.getString("message");
		    		   String l=null;
		    		   l=JSon.getString("message");
		    		   if(l!=null) {
		    			   try {
							jdbcDb db=new jdbcDb();
							String sql=null;
							sql="delete  from room_info where ROOM_NO='"+l+"'";
							db.Update(sql);
							 q.append("{").append("\"state\":").append("\"SUC\"").append("}");	
						} catch (SQLException e) {
						
							 q.append("{").append("\"state\":").append("\"ERR\"").append("}");
						} 
		    		   }
		      }
		    	   else if(k==3) {
		    		   JSONObject JSON=JSONObject.fromObject(JSon.getString("message"));
		    		   String roomNo=null;
		    		   String roomName=null;
		    		   String deviceNum=null;
		    		   String deviceCapacity=null;
		    		   String deviceDescribe=null;
		    		   roomNo=JSON.getString("roomNo");
		    		   roomName=JSON.getString("roomName");
		    		   deviceNum=JSON.getString("deviceNum");
		    		   deviceCapacity=JSON.getString("deviceCapacity");
		    		   deviceDescribe=JSON.getString("deviceDescribe");
		      String sql=null;
		      sql="update room_info set ROOM_NO='"+roomNo+"',NAME='"+roomName+"',DEVICE_NUM='"+deviceNum+"',DEVICE_CAPACITY='"+deviceCapacity+"',DEVICE_DESCRIBE='"+deviceDescribe+"' where ROOM_NO='"+roomNo+"'";
		      try {
				jdbcDb db =new jdbcDb();
				db.Update(sql);
				 q.append("{").append("\"state\":").append("\"SUC\"").append("}");	
			} catch (SQLException e) {
				 q.append("{").append("\"state\":").append("\"ERR\"").append("}");	
			}  
		     }
		    	   else if(k==4) {
		    		   JSONObject JSON=JSONObject.fromObject(JSon.getString("message"));
		    		   String roomNo=null;
		    		   String roomName=null;
		    		   String deviceNum=null;
		    		   String deviceCapacity=null;
		    		   String deviceDescribe=null;
		    		   roomNo=JSON.getString("roomNo");
		    		   roomName=JSON.getString("roomName");
		    		   deviceNum=JSON.getString("deviceNum");
		    		   deviceCapacity=JSON.getString("deviceCapacity");
		    		   deviceDescribe=JSON.getString("deviceDescribe");
		                String sql=null; 
		              sql=" Insert into room_info(ROOM_NO,NAME,DEVICE_NUM,DEVICE_CAPACITY,DEVICE_DESCRIBE) values('"+roomNo+"','"+roomName+"','"+ deviceNum+"','"+deviceCapacity+"','"+deviceDescribe+"')";
		                try {
		    				jdbcDb db =new jdbcDb();
		    				db.Update(sql);
		    				 q.append("{").append("\"state\":").append("\"SUC\"").append("}");	
		    			} catch (SQLException e) {
		    				 q.append("{").append("\"state\":").append("\"ERR\"").append("}");	
		    			}  
		    	   }
		    	   else  if(k==5) {
		    		   JSONObject JSON=JSONObject.fromObject(JSon.getString("message"));
		    		 String l=null,r=null;
		    		 l=JSON.getString("roomNo");
		    		 r=JSON.getString("week");
		    		 if(l!=null&&r!=null) {
		    		 try {
						jdbcDb db=new jdbcDb();
						String sql=null;
						if(l.compareTo("0")==0&&r.compareTo("0")!=0)
							sql="select *from arrange_info where ARRANGE_WEEK='"+r+"'";
						else if(l.compareTo("0")!=0&&r.compareTo("0")==0)
							sql="select *from arrange_info where FK_ ROOM_NO='"+l+"'";
						else if(l.compareTo("0")!=0&&r.compareTo("0")!=0)
							sql="select *from arrange_info where (FK_ ROOM_NO='"+l+"' and ARRANGE_WEEK='"+r+"')";
						else if(l.compareTo("0")==0&&r.compareTo("0")==0)
							sql="select *from arrange_info";
						ResultSet rs=null;
						rs=db.select(sql);
						if(rs.next()) {
							rs.previous();
							    q.append("{").append("\"state\":").append("\"SUC\"").append(",");
							     q.append("\"message\":").append("[");
							while(rs.next()) {
								if(rs.getRow()!=1)
									q.append(",");
								q.append("{").append("\"arrangeNo\":").append("\"").append(rs.getString(1)).append("\"");
								q.append(",").append("\"fkappNo\":").append("\"").append(rs.getString(2)).append("\"");
								q.append(",").append("\"fkExpitemNo\":").append("\"").append(rs.getString(3)).append("\"");
								q.append(",").append("\"stuNum\":").append("\"").append(rs.getString(4)).append("\"");
								q.append(",").append("\"fkRoomNo\":").append("\"").append(rs.getString(5)).append("\"");			
								q.append(",").append("\"arrangeWeek\":").append("\"").append(rs.getString(6)).append("\"");
								q.append(",").append("\"arrangeDay\":").append("\"").append(rs.getString(7)).append("\"");
								q.append(",").append("\"arrangeInterval\":").append("\"").append(rs.getString(8)).append("\"");
							    q.append("}");
							}
							q.append("]").append("}");
						}
						else {
							 q.append("{").append("\"state\":").append("\"ER\"").append("}");	
						}
					} catch (SQLException e) {
						 q.append("{").append("\"state\":").append("\"ERR\"").append("}");	
					}
		    		   }
		    	   }
		    	   else if(k==6) {
		    		   try {
		    		   jdbcDb db=new jdbcDb();
		    		   ResultSet rs=null;
		    		   String sql=null;
		    		  sql="select *from arrange_info";
		    		    rs=db.select(sql);
		    		   if(rs.next()) {
							rs.previous();
						 q.append("{").append("\"state\":").append("\"SUC\"").append(",");
					       q.append("\"message\":").append("[");
							while(rs.next()) {
								if(rs.getRow()!=1)
									q.append(",");
								q.append("{").append("\"arrangeNo\":").append("\"").append(rs.getString(1)).append("\"");
								q.append(",").append("\"fkappNo\":").append("\"").append(rs.getString(6)).append("\"");
								q.append(",").append("\"fkExpitemNo\":").append("\"").append(rs.getString(7)).append("\"");
								q.append(",").append("\"stuNum\":").append("\"").append(rs.getString(2)).append("\"");
								q.append(",").append("\"fkRoomNo\":").append("\"").append(rs.getString(8)).append("\"");			
								q.append(",").append("\"arrangeWeek\":").append("\"").append(rs.getString(3)).append("\"");
								q.append(",").append("\"arrangeDay\":").append("\"").append(rs.getString(4)).append("\"");
								q.append(",").append("\"arrangeInterval\":").append("\"").append(rs.getString(5)).append("\"");
							    q.append("}");
							}
							q.append("]").append("}");
						}
						else {
							 q.append("{").append("\"state\":").append("\"ER\"").append("}");	
						}
					} catch (SQLException e) {
						 q.append("{").append("\"state\":").append("\"ERR\"").append("}");	
					}
		    	   }
		  JSONObject pax=JSONObject.fromObject(q.toString());
		  PrintWriter out=response.getWriter();
			String Json=pax.toString();
            Json=URLEncoder.encode(Json,"utf-8");
		  out.println(Json);
		    }
}
}
