package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.jdbcDb;
import net.sf.json.JSONObject;

public class expItemManageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public expItemManageServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		  String json=null;
	   if(request.getParameter("data")!=null)
	    	json=request.getParameter("data");   
	   if(json!=null) {
	   JSONObject jSon=JSONObject.fromObject(json.toString());
	   int k=Integer.parseInt(jSon.getString("state"));
	   StringBuffer p=new StringBuffer();   
	   if(k==1) {
	 	      String expItemNo=null;
	 	      expItemNo=jSon.getString("message");
	 	      try {
				jdbcDb db=new jdbcDb();
				String sql=null;
				sql="delete *from exp_item where EXP_ITEM_NO='"+expItemNo+"'";
				db.Update(sql);
				p.append("{").append("\"state\":").append("\"SUC\"").append("}");
			} catch (SQLException e) {
				p.append("{").append("\"state\":").append("\"ERR\"").append("}");
			}
	 	    }
	 	    else if(k==2) {
	 	    	String expItemNo=null;
	 	    	String expItemHour=null;
	 	    	String expType=null;
	 	    	String expItemName=null;
	 	    	String courseNo=null;
	 	    	JSONObject JSON=JSONObject.fromObject(jSon.getString("message"));
	            expItemNo=JSON.getString(" expItemNo");
	            expItemHour=JSON.getString("expItemHour");
	            expType=JSON.getString("expType");
	            expItemName=JSON.getString("expItemName");
	            courseNo=JSON.getString("courseNo");
	            try {
					jdbcDb db=new jdbcDb();
			String Sql="update exp_item set EXP_ITEM_NO='"+expItemNo+"',EXP_ITEM_HOUR='"+expItemHour+"',EXP _TYPE='"+expType+"',EXP_ITEM_NAME='"+expItemName+"',FK_COURSE_NO='"+courseNo+"'where EXP_ITEM_NO='"+expItemNo+"'";
			db.Update(Sql);
			p.append("{").append("\"state\":").append("\"SUC\"").append("}");
				} catch (SQLException e) {
				
					p.append("{").append("\"state\":").append("\"ERR\"").append("}");
				}
	 	    }
	 	    else if(k==3) {
	 	    	String expItemNo=null;
	 	    	String expItemHour=null;
	 	    	String expType=null;
	 	    	String expItemName=null;
	 	    	String courseNo=null;
	 	    	JSONObject JSON=JSONObject.fromObject(jSon.getString("message"));
	            expItemNo=JSON.getString(" expItemNo");
	            expItemHour=JSON.getString("expItemHour");
	            expType=JSON.getString("expType");
	            expItemName=JSON.getString("expItemName");
	            courseNo=JSON.getString("courseNo");
	            try {
					jdbcDb db=new jdbcDb();
			 String Sql="Insert into exp_item(EXP_ITEM_NO,EXP_ITEM_HOUR,EXP _TYPE,EXP_ITEM_NAME,FK_COURSE_NO) values('"+expItemNo+"','"+expItemHour+"','"+expType+"','"+expItemName+"','"+courseNo+"')";
			         db.Update(Sql);
			p.append("{").append("\"state\":").append("\"SUC\"").append("}");
				} catch (SQLException e) {
				
					p.append("{").append("\"state\":").append("\"ERR\"").append("}");
				}
	 	  }
	 	JSONObject Json=JSONObject.fromObject(p.toString());
		String JSon=Json.toString();
	    JSon=URLEncoder.encode(JSon,"utf-8");
	 	PrintWriter out=response.getWriter();
	 	out.println(JSon);
		}
	}
	}
