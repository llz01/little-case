package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.jdbcDb;
import net.sf.json.JSONObject;

public class Register extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public Register() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		   String data=null;
		if(request.getParameter("data")!=null)
	    	 data=request.getParameter("data");
		   if(data!=null) {
			   String teacherNo=null,teacherName=null,teacherTell=null;
			   String teacherPwd=null,teacherEmail=null;
			   JSONObject jSon=JSONObject.fromObject(data.toString());
			   teacherNo=jSon.getString("teacherNo");
			   teacherName=jSon.getString("teacherName");
			   teacherTell=jSon.getString("teacherTell");
			   teacherPwd=jSon.getString("teacherPwd");
			   teacherEmail=jSon.getString("teacherEmail");
			    try {
					jdbcDb db=new jdbcDb();
					ResultSet rs=null;
					String sql="select * from teacher_info where teacher_no='"+teacherNo+"'";
					rs=db.select(sql);
					StringBuffer json=new StringBuffer();
					if(!rs.next()) {
						json.append("{").append("\"state\":").append("\"ERR\"");
						json.append("}");
					}
					else {
String Sql="insert into teacher_info(TEACHER_NO,TEACHER_NAME,TEACHER_TELL,TEACHER_PWD,TEACHER_EMAIL) values('"+teacherNo+"','"+teacherName+"','"+teacherTell+"','"+teacherPwd+"','"+teacherEmail+"')";
                 jdbcDb DB=new jdbcDb();
                 DB.Update(Sql);
                 json.append("{").append("\"state\":").append("\"SUC\"").append("}");
					}
					 PrintWriter out=response.getWriter();
					 JSONObject  JSON = JSONObject.fromObject(json.toString());
					 out.println(JSON);
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
		   }
	}

}
