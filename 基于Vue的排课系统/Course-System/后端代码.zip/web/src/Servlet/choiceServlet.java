package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.jdbcDb;
import net.sf.json.JSONObject;

public class choiceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public choiceServlet() {
        super();
       
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	           StringBuffer q=new StringBuffer();
	           request.setCharacterEncoding("utf-8");
	 		  String json=null;
	  	   if(request.getParameter("data")!=null)
	 	    	json=request.getParameter("data");   
	  	   if(json!=null) {
	           try {
	        	  JSONObject jSon=JSONObject.fromObject(json.toString());
	        	  JSONObject JSon=JSONObject.fromObject(jSon.getString("message"));
	        	String week=JSon.getString("week");
	        	String num=JSon.getString("num");
				jdbcDb db=new jdbcDb();
				q.append("{").append("\"state\":").append("\"SUC\",").append("\"message\":").append("[");
				for(int i=1;i<=7;i++) {
					  if(i!=1)
						  q.append(",");
					q.append("{");
					for(int j=1;j<=5;j++)
					{
						if(j!=1)
							q.append(",");
String sql="SELECT COURSE_NAME FROM course_info WHERE COURSE_NO IN(SELECT PK_COURSE_NO FROM exp_item WHERE EXP_ITEM_NO IN(SELECT FK_EXP_ITEM_NO FROM arrange_info WHERE (ARRANGE_WEEK='"+week+"' AND ARRANGE_DAY='"+i+"' AND ARRANGE_INTERVAL='"+j+"' AND FK_ROOM_NO='"+num+"')))";
				ResultSet rs=null;	
				rs=db.select(sql);
				if(rs.next()) {
					rs.previous();
					while(rs.next()) {
					q.append("\"").append(j).append("\":").append("\"").append(rs.getString(1)).append("\"");
				      break;
					}
				}
				else {
					q.append("\"").append(j).append("\":").append("\"0\"");
					} 
					}
					q.append("}");
				}
				q.append("]").append("}");
				 JSONObject Json=JSONObject.fromObject(q.toString());
				
				 String JSOn=Json.toString();
	              JSOn=URLEncoder.encode(JSOn,"utf-8");
			 	 	PrintWriter out=response.getWriter();
			 	 	out.println(JSOn);
			} catch (SQLException e) {
			
				e.printStackTrace();
			}
	}
	}
}
