package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.jdbcDb;
import net.sf.json.JSONObject;

public class QueryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public QueryServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);   
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  request.setCharacterEncoding("utf-8");
		  String json=null;
 	   if(request.getParameter("data")!=null)
	    	json=request.getParameter("data");   
 	   if(json!=null) {
 	   JSONObject jSon=JSONObject.fromObject(json.toString());
 	   int k=Integer.parseInt(jSon.getString("state"));
 	   StringBuffer p=new StringBuffer();
 	  String q=null;
 	    if(k==1) {
 	    	    String teacherNo=null;
 	 	      teacherNo=jSon.getString("message");
 	 	      System.out.println(teacherNo);
 	 	    try {
 	 			jdbcDb db=new jdbcDb();
 	 			q="SELECT P.FK_COURSE_NO, P.COURSE_IDX, P.APP_STU_NUM, P.FK_CLASS_NO, P.FK_TEACHER_NO,P.APP_TERM,";
 	 			q+="R.FK_EXP_ITEM_NO,R.ARRANGE_NO,R.FK_ROOM_NO,R.STU_NUM,R.ARRANGE_WEEK,R.ARRANGE_DAY,R.ARRANGE_INTERVAL ";
 	 			q+=" from app_info P LEFT OUTER  JOIN arrange_info  R ON( P.APP_NO=R.FK_APP_NO)  WHERE  P.FK_TEACHER_NO='"+teacherNo+"'";
 	 		System.out.println(q);
 	           String Sql=q;
 	 	       ResultSet rs=null;
 	 	       rs=db.select(Sql);
 	 	       if(rs.next()) {
 	 	p.append("{").append("\"state\":").append("\"SUC\"").append(",");
 	 	p.append("\"message\":").append("[");
 	 	    rs.previous();
 	 	    while(rs.next()) {
 	 	    	  if(rs.getRow()!=1)
 	 	    		   p.append(",");
 	  p.append("{").append("\"courseNo\":").append("\"").append(rs.getString(1)).append("\"");
 	  p.append(",").append("\"courseIdx\":").append("\"").append(rs.getString(2)).append("\"");
 	  p.append(",").append("\"stuNum\":").append("\"").append(rs.getString(3)).append("\"");	    
 	  p.append(",").append("\"classNo\":").append("\"").append(rs.getString(4)).append("\"");	
 	  p.append(",").append("\"teacherNo\":").append("\"").append(rs.getString(5)).append("\"");
 	  p.append(",").append("\"appTeam\":").append("\"").append(rs.getString(6)).append("\"");
 	  p.append(",").append("\"arraneNo\":").append("\"").append(rs.getString(7)).append("\"");
 	  p.append(",").append("\"expItemNo\":").append("\"").append(rs.getString(8)).append("\"");
 	  p.append(",").append("\"computerSTuNum\":").append("\"").append(rs.getString(9)).append("\"");
 	  p.append(",").append("\"roomNo\":").append("\"").append(rs.getString(10)).append("\"");
 	  p.append(",").append("\"arrangeWeek\":").append("\"").append(rs.getString(11)).append("\"");
 	  p.append(",").append("\"arrangeDay\":").append("\"").append(rs.getString(12)).append("\"");
 	  p.append(",").append("\"arrangeInterval\":").append("\"").append(rs.getString(13)).append("\"}");	    
 	 	    }
 	 	  p.append("]").append("}");
 	 	  }
 	 	  else {
 	 		 p.append("{").append("\"state\":").append("\"ER\"").append("}");
 	 	  }
 	 	
 	 		} catch (SQLException e) {
 	 		
 	 			p.append("{").append("\"state\":").append("\"ERR\"").append("}");
 	 		}
 	    }
 	    else if(k==2) {
 	    	 String teacherNo=null;
	 	      teacherNo=jSon.getString("message");
	 	    try {
	 			jdbcDb db=new jdbcDb();
	 			q="SELECT P.FK_COURSE_NO, P.COURSE_IDX, P.APP_STU_NUM, P.FK_CLASS_NO, P.FK_TEACHER_NO,P.APP_TERM,";
 	 			q+="R.FK_EXP_ITEM_NO,R.ARRANGE_NO,R.FK_ROOM_NO,R.STU_NUM,R.ARRANGE_WEEK,R.ARRANGE_DAY,R.ARRANGE_INTERVAL ";
 	 			q+="FROM  app_info P left outer join arrange_info  R on( P.APP_NO=R.FK_APP_NO)  Where FK_CLASS_NO='"+teacherNo+"'";
	           String Sql=q;
	 	       ResultSet rs=null;
	 	       rs=db.select(Sql);
	 	       if(rs.next()) {
	 	p.append("{").append("\"state\":").append("\"SUC\"").append(",");
	 	p.append("\"message\":").append("[");
	 	      rs.previous();
	 	    while(rs.next()) {
	 	    	 if(rs.getRow()!=1)
	 	    		   p.append(",");
	  p.append("{").append("\"courseNo\":").append("\"").append(rs.getString(1)).append("\"");
	  p.append(",").append("\"courseIdx\":").append("\"").append(rs.getString(2)).append("\"");
	  p.append(",").append("\"stuNum\":").append("\"").append(rs.getString(3)).append("\"");	    
	  p.append(",").append("\"classNo\":").append("\"").append(rs.getString(4)).append("\"");	
	  p.append(",").append("\"teacherNo\":").append("\"").append(rs.getString(5)).append("\"");
	  p.append(",").append("\"appTeam\":").append("\"").append(rs.getString(6)).append("\"");
	  p.append(",").append("\"arraneNo\":").append("\"").append(rs.getString(7)).append("\"");
	  p.append(",").append("\"expItemNo\":").append("\"").append(rs.getString(8)).append("\"");
	  p.append(",").append("\"computerSTuNum\":").append("\"").append(rs.getString(9)).append("\"");
	  p.append(",").append("\"roomNo\":").append("\"").append(rs.getString(10)).append("\"");
	  p.append(",").append("\"arrangeWeek\":").append("\"").append(rs.getString(11)).append("\"");
	  p.append(",").append("\"arrangeDay\":").append("\"").append(rs.getString(12)).append("\"");
	  p.append(",").append("\"arrangeInterval\":").append("\"").append(rs.getString(13)).append("\"}");	    
	 	    }
	 	  p.append("]").append("}");
	 	  }
	 	  else {
	 		 p.append("{").append("\"state\":").append("\"ER\"").append("}");
	 	  }
	 	
	 		} catch (SQLException e) {
	 		
	 			p.append("{").append("\"state\":").append("\"ERR\"").append("}");
	 		}
 	    }
 	   JSONObject Json=JSONObject.fromObject(p.toString());
 	 	PrintWriter out=response.getWriter();
 		String JSon=Json.toString();
        JSon=URLEncoder.encode(JSon,"utf-8");
 	 	out.println(JSon);
 	   }
	}

}
