package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.jdbcDb;
import net.sf.json.JSONObject;


public class adminManageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public adminManageServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  request.setCharacterEncoding("utf-8");
		  String json=null;
 	   if(request.getParameter("data")!=null)
	    	json=request.getParameter("data");   
 	   if(json!=null) {
 	   JSONObject jSon=JSONObject.fromObject(json.toString());
 	   int k=Integer.parseInt(jSon.getString("state"));
 	   StringBuffer p=new StringBuffer();
 	   if(k==1) {
	    	String adName=null;
	    	String adUserName=null;
	    	String adUserPwd=null;
	    	String adTell=null;
	    	String adEmail=null; 	
   JSONObject JSON=JSONObject.fromObject(jSon.getString("message"));
   adUserName=JSON.getString("adUserName");
   adUserPwd=JSON.getString("adUserPwd");
   adTell=JSON.getString("adTell");
   adEmail=JSON.getString("adEmail");
          try {
				jdbcDb db=new jdbcDb();
String Sql="update user_admin set AD_USER_PWD='"+adUserPwd+"',AD_TELL='"+adTell+"',AD_EMAIL='"+adEmail+"' where AD_USER_NAME='"+adUserName+"'";
		db.Update(Sql);
		p.append("{").append("\"state\":").append("\"SUC\"").append("}");
			} catch (SQLException e) {
			
				p.append("{").append("\"state\":").append("\"ERR\"").append("}");
			}
       	JSONObject Json=JSONObject.fromObject(p.toString());
     	PrintWriter out=response.getWriter();
    	String JSon=Json.toString();
        JSon=URLEncoder.encode(JSon,"utf-8");
     	out.println(JSon);
 	   }
	}
	}
}
