package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.jdbcDb;
import net.sf.json.JSONObject;

public class adminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public adminServlet() {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  request.setCharacterEncoding("utf-8");
		  String json=null;
 	    if(request.getParameter("data")!=null)
	    	json=request.getParameter("data");  
 	    if(json!=null) {
 	    	JSONObject jSon=JSONObject.fromObject(json.toString());
 	    	String state=null;
 	 	   state=jSon.getString("state");
 	 	   StringBuffer p=new StringBuffer();
 	 	   if(state.compareTo("SUC")==0) {
 	 		   String adminNo=null;
 	 		   adminNo=jSon.getString("message");
 	 		  try {
 	  			jdbcDb db=new jdbcDb();
 	  	       String Sql="select * from user_admin where AD_NO='"+adminNo+"'";
 	  	       ResultSet rs=null;
 	  	       rs=db.select(Sql);
 	  	       if(rs.next()) {
 	  	p.append("{").append("\"state\":").append("\"SUC\"").append(",");
 	  	p.append("\"message\":").append("[");
 	  	    rs.previous();
 	  	    while(rs.next()) {
 	  	    	if(rs.getRow()!=1)
 	  	    		p.append(",");
 	   p.append("{").append("\"adNo\":").append("\"").append(rs.getString(1)).append("\"");
 	   p.append(",").append("\"adName\":").append("\"").append(rs.getString(2)).append("\"");
 	   p.append(",").append("\"adUserName\":").append("\"").append(rs.getString(3)).append("\"");	    
 	   p.append(",").append("\"adUserPwd\":").append("\"").append(rs.getString(4)).append("\"");	
 	   p.append(",").append("\"adTell\":").append("\"").append(rs.getString(5)).append("\"");	    
 	   p.append(",").append("\"adEmail\":").append("\"").append(rs.getString(6)).append("\"");	    
 	   p.append(",").append("\"userType\":").append("\"").append(rs.getString(7)).append("\"}");	    
 	  	    }
 	  	  p.append("]").append("}");
 	  	  }
 	  	  else {
 	  		 p.append("{").append("\"state\":").append("\"ER\"").append(",");
 	  	  }
 	  	
 	  		} catch (SQLException e) {
 	  		
 	  			p.append("{").append("\"state\":").append("\"ERR\"").append("}");
 	  		}
 	  	JSONObject Json=JSONObject.fromObject(p.toString());
 	  	PrintWriter out=response.getWriter();
 		String JSon=Json.toString();
        JSon=URLEncoder.encode(JSon,"utf-8");
 	  	out.println(JSon);
 	 	}   
 	 		 }
	}
}
